<?php

namespace App\Policies;

class ExpensePolicy extends TenantModelPolicy
{
}
