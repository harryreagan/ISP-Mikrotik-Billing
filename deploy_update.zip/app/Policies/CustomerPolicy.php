<?php

namespace App\Policies;

class CustomerPolicy extends TenantModelPolicy
{
}
